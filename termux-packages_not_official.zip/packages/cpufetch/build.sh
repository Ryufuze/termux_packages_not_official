TERMUX_PKG_HOMEPAGE=https://github.com/Dr-Noob/cpufetch
TERMUX_PKG_DESCRIPTION="Simple yet fancy CPU architecture fetching tool"
TERMUX_PKG_LICENSE="MIT"
TERMUX_PKG_MAINTAINER="@ELWAER-M"
TERMUX_PKG_VERSION=1.02
TERMUX_PKG_SRCURL=https://github.com/Dr-Noob/cpufetch/archive/refs/tags/v${TERMUX_PKG_VERSION}.tar.gz
TERMUX_PKG_SHA256=3d1c80aba3daa5fe300b6de6e06d9030f97b7be5210f8ea4110de733ea4373f8
TERMUX_PKG_BUILD_IN_SRC=true
