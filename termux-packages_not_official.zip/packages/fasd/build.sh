TERMUX_PKG_HOMEPAGE=https://github.com/whjvenyl/fasd
TERMUX_PKG_DESCRIPTION="To fastly access files and folders"
TERMUX_PKG_LICENSE="MIT"
TERMUX_PKG_MAINTAINER="@termux"
TERMUX_PKG_VERSION=1.0.2
TERMUX_PKG_SRCURL=https://github.com/whjvenyl/fasd/archive/${TERMUX_PKG_VERSION}.tar.gz
TERMUX_PKG_SHA256=6e048cfbfe53bf8b806e36db17c4eb2b8e15e8dfaadc759c7ce78e3915716b21
TERMUX_PKG_BUILD_IN_SRC=true
