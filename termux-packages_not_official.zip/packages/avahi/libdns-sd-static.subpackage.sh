TERMUX_SUBPKG_INCLUDE="lib/libdns_sd.a lib/libdns_sd.la"
TERMUX_SUBPKG_DESCRIPTION="Compatibility layer for libdns_sd (static library)"
TERMUX_SUBPKG_DEPENDS="libdns-sd"
