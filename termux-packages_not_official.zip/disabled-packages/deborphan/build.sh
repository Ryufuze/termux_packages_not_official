TERMUX_PKG_HOMEPAGE=https://packages.debian.org/source/sid/deborphan
TERMUX_PKG_DESCRIPTION="Program that can find unused packages"
TERMUX_PKG_LICENSE="MIT"
TERMUX_PKG_MAINTAINER="Pierre Rudloff @Rudloff"
TERMUX_PKG_VERSION=1.7.33
TERMUX_PKG_SRCURL=http://deb.debian.org/debian/pool/main/d/deborphan/deborphan_1.7.33.tar.xz
TERMUX_PKG_SHA256="e0976b87b2b3a1c4deb74c581f3c8638e08a8e233103b6c9b94e859dc68307cb"
TERMUX_PKG_BUILD_IN_SRC=true
